require 'msf/core/post/linux/system'
require 'msf/core/post/linux/priv'

module Msf
module Scripts
module MetaSSH
module Common

include ::Msf::Post::Linux::System
include ::Msf::Post::Linux::Priv

end
end
end
end

