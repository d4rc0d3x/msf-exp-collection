#!/usr/bin/env ruby

require 'rex/post/meta_ssh/client'
require 'rex/post/meta_ssh/ui/console'
